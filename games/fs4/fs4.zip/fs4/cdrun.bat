@echo off
cls
echo Einfach Starten mit FS4
pause

